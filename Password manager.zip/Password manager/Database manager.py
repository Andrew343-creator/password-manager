import mysql.connector
def del_db2():
    try:
        
        cnx = cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "logindatabase")
        cur = cnx.cursor()
        
        query = "DROP DATABASE logindatabase"
        
        cur.execute(query)
        
        cnx.commit()
        
        cur.close()
        cnx.close()
        print("Done")
    except:
        print("Error, No database.")
def del_db1():
    try:
        
        cnx = cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "mydatabase")
        cur = cnx.cursor()
        
        query = "DROP DATABASE mydatabase"
        
        cur.execute(query)
        
        cnx.commit()
        
        cur.close()
        cnx.close()
        print("Done")
    except:
        print("Error, No database.")
def view_db():
    try:
        
        cnx = cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "mydatabase")
        cur = cnx.cursor()
        
        query = "SELECT * FROM userdata"
        
        cur.execute(query)

        results = cur.fetchall()
        
        print(results)
    except:
        print("Error, No data found.")
    
def view_db1():
    try:
        
        cnx = cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "logindatabase")
        cur = cnx.cursor()
        
        query = "SELECT * FROM admin1_data"
        
        cur.execute(query)

        results = cur.fetchall()
        
        print(results)
    except:
        print("Error, No data found.")
print("""
      Enter:
      (1)To delete a master details database.
      (2)To delete user credentials data.
      (3)To view a master credentials database.
      (4)To view a user credentials database.""")

choice = input("Enter your choice:")

if choice == "1":
    del_db2()
elif choice == "2":
    del_db1()
elif choice == "3":
    view_db1()
elif choice == "4":
    view_db()
elif choice == "q":
    print("Good bye")  
else:
    print("Invalid option.")  
import os 
import cryptography.exceptions
from cryptography.fernet import Fernet
import cryptography.fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import binascii
import mysql.connector
import cryptography
import time
import pyotp
import qrcode
from PIL import Image


 

class key_creation:
    def salt_creation():
        path = "salt.env"
        if os.path.isfile(path):
                with open(path,'rb')as f:
                    salt = f.read()
                return salt
        else:
            try:
                salt = binascii.hexlify(os.urandom(32))
                with open(path,'wb')as f:
                    f.write(salt)
                with open(path,'rb')as f:
                    salt = f.read()
                    return salt
            except:
                print("error occurred")
    ##############################################################
    #Encryption mechanics:
         #check if key is available
    def check_if_key_exists():
        try:
            key_path = 'key.key'
            if os.path.isfile(key_path):
                try:#if key exists
                    with open(key_path, 'rb')as f:
                        enc_key = f.read()
                    password = input("Enter the Master_key decryption password:")
                    salt = key_creation.salt_creation()

                    kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                        length = 32,
                                        salt = salt,
                                        iterations = 100000,
                                        )
                    der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                        
                    cipher_suite = Fernet(der_key)
                    
                    try:    
                        decrypted = cipher_suite.decrypt(enc_key)
                       
                        return decrypted
                    
                    except TypeError:
                        print("Wrong password")
                    
                except TypeError:
                    print("Access denied.")
            else:
                #if key does not exist###########################################################################
                key1 = Fernet.generate_key()
                password1 = input("Set the Master_key encryption password:")   
                password2 = input("Confirm the Master_key encryption password:")
                if password1 == password2:
                    password = password1
                    salt = key_creation.salt_creation()
                    kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                    length = 32,
                                    salt = salt,
                                    iterations = 100000,
                                    )
                    der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                    cipher_suite = Fernet(der_key)
                    encrypted = cipher_suite.encrypt(key1)
                
                    with open(key_path, 'wb')as f:
                        f.write(encrypted)
                        
                    with open(key_path,'rb')as f:
                        enc_key = f.read()
                    passwordd = input("Enter the Master_key decryption password:")
                    salt = key_creation.salt_creation()

                    kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                    length = 32,
                                    salt = salt,
                                    iterations = 100000,
                                    )
                    der_key = base64.urlsafe_b64encode(kdf.derive(passwordd.encode()))
                    
                    cipher_suited = Fernet(der_key)
                    
                    decrypted = cipher_suited.decrypt(enc_key)
                    
                    return decrypted
                else:
                    print("Incorrect password.")
                    exit
        except Exception:
            exit



def if_db_exists():
    try:
        cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost" , database = "logindatabe")

        cur = cnx.cursor()
        query1 = "CREATE  TABLE IF NOT EXISTS admin1_data(id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,username VARCHAR(255)NOT NULL,password VARCHAR(255)NOT NULL);"
        cur.execute(query1)
        cnx.commit()
            
        cur.close()
        cnx.close()
        return ("Database exists")
    except mysql.connector.ProgrammingError:
        try:
            cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost")
            cur = cnx.cursor()
        
            query = "CREATE DATABASE IF NOT EXISTS logindatabase"
            cur.execute(query)
            cnx.commit()
        
            cur.close()
            cnx.close()
            ###############################################################################################
            cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "logindatabase")
            cur = cnx.cursor()
            query1 = "CREATE  TABLE IF NOT EXISTS admin1_data(id INT PRIMARY KEY AUTO_INCREMENT,username VARCHAR(255)NOT NULL,password VARCHAR(255)NOT NULL);"
            cur.execute(query1)
            cnx.commit()
        
            cur.close()
            cnx.close()
            return ("Database Has Been Created")
        except mysql.connector.ProgrammingError:
            return False

def data_into_db():
        ###################################################################################################
            cnx = mysql.connector.connect( user = 'root',password = 'And1234()',host = 'localhost',database = 'logindatabase')
            cur = cnx.cursor()
            ###############################################################################################
            username = input("Set your Master_username:")
            password1 = input("Set your Master_password:")
            #encryption of password########################################################################
            key = key_creation.check_if_key_exists()
            
            cipher_suite = Fernet(key)
            
            password = cipher_suite.encrypt(password1.encode())
        ##################################################################################################     
            

            values = (username, password)
            
            query1 = "INSERT INTO admin1_data(username,password) VALUES(%s,%s)"
            cur.execute(query1, values)
            cnx.commit()

            cur.close()
            cnx.close()

def usr1_dict():
    usr_dict = {}
    cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "logindatabase")
    cur = cnx.cursor()
        
    query = "SELECT * FROM admin1_data"
    cur.execute(query)
    
    rows = cur.fetchall()
    
    for row in rows:
        usr_dict[row[1]] = row[2]
        
    cnx.commit()
    
    cur.close()
    cnx.close()    
    
    return usr_dict

def salt_creation():
        path = "@@@salt.env"
        if os.path.isfile(path):
                with open(path,'rb')as f:
                    salt = f.read()
                return salt
        else:
            try:
                salt = binascii.hexlify(os.urandom(32))
                with open(path,'wb')as f:
                    f.write(salt)
                with open(path,'rb')as f:
                    salt = f.read()
                    return salt
            except:
                print("error occurred")

def FA_key():
    try:
        key_path = "@@@KY.key" 
        if os.path.isfile(key_path):
            #if key exists
            with open(key_path, 'rb')as f:
                enc_key = f.read()
                
            password = input("Enter the 2FA KEY decryption password:")
            
            salt = salt_creation()

            kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                length = 32,
                                salt = salt,
                                iterations = 100000,
                                )
            der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                
            cipher_suite = Fernet(der_key)
                
            decrypted = cipher_suite.decrypt(enc_key).decode()
            
            return decrypted
        
        else:
            #if key does not exist###########################################################################
            key1 = pyotp.random_base32()
            password1 = input("Set the 2FA KEY encryption password:")   
            password2 = input("Confirm the 2FA KEY encryption password:")
            if password1 == password2:
                password = password1
                salt = salt_creation()
                kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                    length = 32,
                                    salt = salt,
                                    iterations = 100000,
                                    )
                der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                cipher_suite = Fernet(der_key)
                encrypted = cipher_suite.encrypt(key1.encode())
                
                with open(key_path, 'wb')as f:
                    f.write(encrypted)
                        
                with open(key_path,'rb')as f:
                    enc_key = f.read()
                passwordd = input("Enter the 2FA KEY decryption password:")
                    
                salt = salt_creation()
                kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                    length = 32,
                                    salt = salt,
                                    iterations = 100000,
                                    )
                der_key = base64.urlsafe_b64encode(kdf.derive(passwordd.encode()))
                    
                cipher_suited = Fernet(der_key)
                    
                decrypted = cipher_suited.decrypt(enc_key).decode()
                    
                return decrypted, True
            else:
                print("Incorrect password.")
    except Exception as e:
        return False

def verify_gen():
    key = FA_key()
    
          
    uri = pyotp.TOTP(key).provisioning_uri(name="Admin",
                                            issuer_name="Owner")
    totp = pyotp.TOTP(key)
        ##############################################################################
        #Generate QRcode
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,)
        
    qr.add_data(uri)
        
    qr.make(fit=True)
        
    img = qr.make_image(fill='black', back_color='white')
        
    img.show()
    
    if totp.verify(input("Enter the code:")) is True:
        return True 
    
    ##############################################################################
    else:
        print("Wrong password!!!")
        exit

def verify():
    usr_dict = usr1_dict()

    username1 = input("Enter your Master_username:")
    password1 = input("Enter your Master_password:")
    
    
    
    for key,value in usr_dict.items():
        username, password = key,value
    try:
        key1 = key_creation.check_if_key_exists()
        cipher_suite = Fernet(key1)
        
        decrypted = cipher_suite.decrypt(password).decode()
        
        if username1 == username and password1 == decrypted:
            result = verify_gen()
            if result == True:
                
                #############################################################
                print("""
                    How to use the tool:
                    (1)Install mysql; Then create a Database.
                    (2)Install the following modules in python.
                    (3)Replace the password and user for the connection to server i.e cnx = mysql.connector.connect( user = 'Your username',password = 'Your_password',host = 'Your_host',database = 'mydatabase')
                After completing the tasks above you can now store your passwords successfully. Good luck
                    Remember Do Not Repeat The Same Username or Account or Site for the Same Password!!! For if you do that the previous password will be lost.""")
                def if_db_exists():
                    try:
                        cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost" , database = "mydatabase")

                        cur = cnx.cursor()
                        query1 = "CREATE  TABLE IF NOT EXISTS userdata(id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,username VARCHAR(255)NOT NULL,password VARCHAR(255)NOT NULL);"
                        cur.execute(query1)
                        cnx.commit()
                            
                        cur.close()
                        cnx.close()
                        print("Database exists")
                    except mysql.connector.ProgrammingError:
                        try:
                            cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost")
                            cur = cnx.cursor()
                        
                            query = "CREATE DATABASE IF NOT EXISTS mydatabase"
                            cur.execute(query)
                            cnx.commit()
                        
                            cur.close()
                            cnx.close()
                            ###############################################################################################
                            cnx = mysql.connector.connect(user = "root",password ="And1234()",host = "localhost", database = "mydatabase")
                            cur = cnx.cursor()
                            query1 = "CREATE  TABLE IF NOT EXISTS userdata(id INT PRIMARY KEY AUTO_INCREMENT,username VARCHAR(255)NOT NULL,password VARCHAR(255)NOT NULL);"
                            cur.execute(query1)
                            cnx.commit()
                        
                            cur.close()
                            cnx.close()
                            return ("Database Has Been Created")
                        except mysql.connector.ProgrammingError:
                            return False
                    
                class key_creation2:
                    def salt_creation():
                        path = "salt.env"
                        if os.path.isfile(path):
                                with open(path,'rb')as f:
                                    salt = f.read()
                                return salt
                        else:
                            try:
                                salt = binascii.hexlify(os.urandom(32))
                                with open(path,'wb')as f:
                                    f.write(salt)
                                with open(path,'rb')as f:
                                    salt = f.read()
                                    return salt
                            except:
                                print("error occurred")
                    ##############################################################
                    #Encryption mechanics:
                        #check if key is available
                    def check_if_key_exists():
                        key_path = 'key1.key'
                        if os.path.isfile(key_path):
                            #if key exists
                            with open(key_path, 'r')as f:
                                enc_key = f.read()
                            password = input("Enter the decryption password:")
                            salt = key_creation.salt_creation()

                            kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                                length = 32,
                                                salt = salt,
                                                iterations = 100000,
                                                )
                            der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                                
                            cipher_suite = Fernet(der_key)
                                
                            decrypted = cipher_suite.decrypt(enc_key)
                            
                            return decrypted
                        
                        else:
                            #if key does not exist###########################################################################
                            key1 = Fernet.generate_key()
                            password1 = input("Set the encryption password:")   
                            password2 = input("Confirm the encryption password:")
                            if password1 == password2:
                                password = password1
                                salt = key_creation.salt_creation()
                                kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                                length = 32,
                                                salt = salt,
                                                iterations = 100000,
                                                )
                                der_key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
                                cipher_suite = Fernet(der_key)
                                encrypted = cipher_suite.encrypt(key1)
                            
                                with open(key_path, 'wb')as f:
                                    f.write(encrypted)
                                    
                                with open(key_path,'r')as f:
                                    enc_key = f.read()
                                passwordd = input("Enter the decryption password:")
                                salt = key_creation.salt_creation()

                                kdf = PBKDF2HMAC(algorithm = hashes.SHA512_256(),
                                                length = 32,
                                                salt = salt,
                                                iterations = 100000,
                                                )
                                der_key = base64.urlsafe_b64encode(kdf.derive(passwordd.encode()))
                                
                                cipher_suited = Fernet(der_key)
                                
                                decrypted = cipher_suited.decrypt(enc_key)
                                
                                return decrypted
                ##############################################################      
                #DB mechanics
                class insert_data_to_db:
                        def data_into_db():
                        ###################################################################################################
                            cnx = mysql.connector.connect( user = 'root',password = 'And1234()',host = 'localhost',database = 'mydatabase')
                            cur = cnx.cursor()
                            ###############################################################################################
                            username = input("Enter username:")
                            password1 = input("Enter password:")
                            #encryption of password########################################################################
                            key = key_creation2.check_if_key_exists()
                            
                            cipher_suite = Fernet(key)
                            
                            password = cipher_suite.encrypt(password1.encode())
                        ##################################################################################################     
                            

                            values = (username, password)
                            
                            query1 = "INSERT INTO userdata(username,password) VALUES(%s,%s)"
                            cur.execute(query1, values)
                            cnx.commit()

                            cur.close()
                            cnx.close()
                            
                        ###########################################################
                        #dictionary_creation
                        def usr_dict():
                            cnx = mysql.connector.connect( user = 'root' ,
                                                    password = 'And1234()',
                                                    host = 'localhost',
                                                    database = 'mydatabase')
                            cur = cnx.cursor()
                            
                            query = "SELECT * FROM userdata"
                            cur.execute(query)
                            
                            results = cur.fetchall()
                            
                            user_dict = {}
                            
                            for row in results:
                                user_dict[row[1]] = row[2]               
                            

                            cnx.commit()
                            
                            cur.close()
                            cnx.close()
                            
                            return user_dict
                            
                        def decrypt_password():
                            try:
                                dict = insert_data_to_db.usr_dict()
                                name = input("Enter the account or site:")
                                for key,value in dict.items():
                                    if name == key:
                                        password1 = value
                                        key1 = key_creation2.check_if_key_exists()
                                        
                                        cipher_suite = Fernet(key1)
                                        
                                        original_password = cipher_suite.decrypt(password1).decode()
                                        
                                        result = print(f"The password for {name} is {original_password}")
                                    else:
                                        exit
                                return result
                            except:
                                print("No usernames and passwords were found.")
                                if_db_exists()
                                key_creation.check_if_key_exists()
                                insert_data_to_db.data_into_db()
                                insert_data_to_db.usr_dict()
                                insert_data_to_db.decrypt_password()

                def add_password():
                    try:
                        insert_data_to_db.data_into_db()
                    except:
                        if_db_exists()
                        key_creation2.check_if_key_exists()
                        insert_data_to_db.data_into_db() 
                                
                def retrieve_password():
                    insert_data_to_db.decrypt_password()

                print("""Enter:
                    (1)For Adding user account and password.
                    (2)For retrieving password for a User account.
                    (q)For Quiting.
                    """)
                choice = input("Enter choice:")

                if choice == "1":
                    add_password()
                elif choice == "2":
                    retrieve_password()
                elif choice == "q":
                    print("Good bye")
                    exit
                else:
                    print("You have choosen an invalid option")
        else:
            print("Access denied")   
    except TypeError:
        print("Access denied")  
        exit

try:
    verify()
except mysql.connector.ProgrammingError:#sign up
    if_db_exists()
    data_into_db()       
    verify()
       